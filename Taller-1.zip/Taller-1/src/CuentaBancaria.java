/**
 *
 * @author Keinner Ramos
 */

public class CuentaBancaria {
    int numeroCuenta;
    int saldoCuenta;
    String tipoCuenta;
    
    public CuentaBancaria(int numeroCuenta, int saldoCuenta) {
        this.numeroCuenta = numeroCuenta;
        this.saldoCuenta = saldoCuenta;
    }
    
    public CuentaBancaria(int numeroCuenta, int saldoCuenta, String tipoCuenta) {
        this.numeroCuenta = numeroCuenta;
        this.saldoCuenta = saldoCuenta;
        this.tipoCuenta = tipoCuenta;
    }
}
